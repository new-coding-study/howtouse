// import { useNavigate } from 'react-router-dom';
import FooterCSS from './Footer.module.css';
import header from './header.png';

function Footer(){
    // const navigate = useNavigate();

    // const onClickLogoHandler = () => {
    //     navigate("/", {replace:true})
    // }
    // {process.env.PUBLIC_URL + '/myImagePath.jpg'}
    return (
        <div className={FooterCSS.footerDiv}>
            

            <p className={FooterCSS.footerContent}>FAQ</p>
            <p className={FooterCSS.footerContent}>메일로 문의하기</p>
            <p className={FooterCSS.footerContent}>작품 추천</p>

        </div>
    )
}
export default Footer;