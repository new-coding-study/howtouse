
import { useState } from "react";
import { useDispatch } from 'react-redux';
import LoginModalCSS from './LoginModal.module.css';
import { useNavigate } from 'react-router-dom';

import {
    callLoginAPI
} from '../../apis/MemberAPICalls'

function LoginModal({setLoginModal}) {
    const navigate = useNavigate();

    const dispatch = useDispatch();

    const [form, setForm] = useState({
        memberId: '',
        memberPassword: ''
    });
    
    const onChangeHandler = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };
    
    const onClickLoginHandler = () => {
        console.log('[LoginModal] Login Process Start!!');        
        window.localStorage.removeItem('accessToken');
        
        dispatch(callLoginAPI({	// 로그인
            form: form
        }));

        setLoginModal(false);
        console.log('[LoginModal] Login Process End!!');
        alert('로그인이 완료되었습니다.');
        window.location.reload();
    }
    
    return (        
        <div className={LoginModalCSS.modal}>
            <div className={ LoginModalCSS.modalContainer }>
                <div >
                    <h1 className={LoginModalCSS.title}>로그인</h1>
                    <input className={LoginModalCSS.info}
                        type="text" 
                        name='memberId'
                        placeholder="아이디" 
                        autoComplete='off'
                        onChange={ onChangeHandler }
                    />
                    <input className={LoginModalCSS.info}
                        type="password"
                        name='memberPassword' 
                        placeholder="패스워드" 
                        autoComplete='off'
                        onChange={ onChangeHandler }
                    />
                    <br></br>
                    <button className={LoginModalCSS.btn}
                        onClick={ onClickLoginHandler }
                    >
                        로그인
                    </button>
                    <button
                        className={LoginModalCSS.btn}                        
                        onClick={ () => {setLoginModal(false);  navigate(-1)}}
                    >
                        돌아가기
                    </button>
                </div>
            </div>
        </div>
    )
}

export default LoginModal;