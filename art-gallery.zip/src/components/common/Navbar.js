import { NavLink } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useState } from 'react';
import { decodeJwt } from '../../utils/tokenUtils';
import {
    callLogoutAPI
} from '../../apis/MemberAPICalls'
import LoginModal from './LoginModal';
import NavbarCSS from './Navbar.module.css';
import Login from '../../pages/member/Login';

function Navbar(){
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const isLogin = window.localStorage.getItem('accessToken');    // Local Storage 에 token 정보 확인

    const [loginModal, setLoginModal] = useState(false);

    
    let decoded = null;

    if(isLogin !== undefined && isLogin !== null) {
        const temp = decodeJwt(window.localStorage.getItem("accessToken"));
        decoded = temp.auth[0];
    }
    console.log('decoded ', decoded);
    const onClickLogoutHandler = () => {
        window.localStorage.removeItem('accessToken');  
        //로그아웃
        dispatch(callLogoutAPI());
        
        alert('로그아웃이 되어 메인화면으로 이동합니다.');
        navigate("/", { replace: true })
        window.location.reload();
    }

    const onClickHandler = ()=>{
          // 로그인 상태인지 확인
          const token = decodeJwt(window.localStorage.getItem("accessToken"));
          console.log('[onClickHandler] token : ', token);
  
          if(token === undefined || token === null) {
              alert('로그인을 먼저해주세요');
              setLoginModal(true);
              return ;
          }
  
          // 토큰이 만료되었을때 다시 로그인
          if (token.exp * 1000 < Date.now()) {
              setLoginModal(true);
              return ;
          }
    }
    function BeforeLogin() {

        return (
            <div style={{color:"white"}}>
                <NavLink to="auth/login" className={NavbarCSS.navStyle}>로그인</NavLink>  |  <NavLink to="auth/register" className={NavbarCSS.navStyle}>회원가입</NavLink>
            </div>
        );
    }

    function AfterLogin() {

        return (            
            <div>
                <button  onClick={ onClickLogoutHandler } className={NavbarCSS.logoutbtn}>로그아웃</button>
            </div>
        );
    }
    return(
        <div className={NavbarCSS.entireNav}>

            {loginModal ? <LoginModal setLoginModal={ setLoginModal }/> : null}
            <NavLink to='/api/v1/arts/modern' className={NavbarCSS.navStyle}>1관</NavLink>
            <NavLink to='/api/v1/arts/contemporary' className={NavbarCSS.navStyle} onClick={onClickHandler}>2관</NavLink>
            { decoded ==="ROLE_ADMIN" && <NavLink to="/api/v1/arts-management" className={NavbarCSS.navStyle}>작품등록</NavLink>}
            <div className={NavbarCSS.loginBox}>

            {/* 로그인 상태에 따라 다른 컴포넌트 랜더링 */}
            { (isLogin == null || isLogin === undefined) ? <BeforeLogin /> : <AfterLogin />}
            </div>

        </div>
    )
}
export default Navbar;