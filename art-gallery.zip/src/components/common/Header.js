import { useNavigate } from 'react-router-dom';
import HeaderCSS from './Header.module.css';
import header from './header.png';

function Header(){
    const navigate = useNavigate();

    const onClickLogoHandler = () => {
        navigate("/", {replace:true})
    }
    // {process.env.PUBLIC_URL + '/myImagePath.jpg'}
    return (
        <div className={HeaderCSS.headerDiv}>
            <button onClick={onClickLogoHandler} className={HeaderCSS.btn}>     
            <img width={'100px'} height={'100px'} src={header} alt="파레트사진"/>            
            </button>

            <h1 className={HeaderCSS.headerTitle}>Online Art Gallery</h1>
        </div>
    )
}
export default Header;