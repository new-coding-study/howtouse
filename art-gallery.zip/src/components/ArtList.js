import {useNavigate} from 'react-router-dom';
import ArtListCSS from './ArtList.module.css';

function ArtList({art : {artNo, artImageUrl, artName}}){
    const navigate = useNavigate();
// 왜 구조분해 할당을 요소별로 가져와야만 화살표 함수가 인식될까?
    const onClickHandler= (artNo) => {
        navigate(`/api/v1/art/${artNo}` );
    }
  

    return(
        <div className={ArtListCSS.artListDiv} onClick={() => onClickHandler(artNo)}>
            <img className={ArtListCSS.artListImg} src={artImageUrl} alt="명화사진"/>
            <h5 className={ArtListCSS.artListName}>{artName}</h5>
        </div>
    )
}
export default ArtList;