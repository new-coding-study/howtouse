import {Outlet} from "react-router-dom";
import Header from "../components/common/Header";
import Navbar from "../components/common/Navbar";
import Footer from "../components/common/Footer";
import MainCss from './Maincss.module.css';


function Layout(){
    return(
        <>
            <Header/>
            <Navbar/>
            <main className={MainCss.galleryTable}>
                <Outlet/>
            </main>
            <Footer/>
        
        </>
    )
}

export default Layout;