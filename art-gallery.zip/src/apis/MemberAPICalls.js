import{POST_LOGIN, POST_REGISTER} from '../modules/MemberModule';

export const callLoginAPI = ({form})=>{
    // const requestURL = `http://${process.env.REACT_APP_RESTAPI_IP}:8003/auth/login`;
    const requestURL = `http://localhost:8003/auth/login`;

    return async (dispatch, getState) => {
        const result = await fetch(requestURL, {method: "POST",
            headers : {
                "Content-Type": "application/json",
                "Accept":"*/*"
                // ,
                // "Access-Controll-Arrow-Origin":"*"
            },
            body: JSON.stringify({
                memberId: form.memberId,
                memberPassword: form.memberPassword
            })
        }).then(response => response.json());

        console.log('callLogin API result : ', result);
        // console.log('callLogin API result : '+result);
        if(result.status === 200){
            window.localStorage.setItem('accessToken', result.data.accessToken);
        }
        dispatch({type: POST_LOGIN, payload : result});


    };
}

export const callLogoutAPI = () =>{
    return async (dispatch, getState)=> {
        dispatch({type: POST_LOGIN, payload : ''});
        console.log('callLogoutAPI result : success')
    }
}

export const callRegisterAPI = ({form}) => {
    const requestURL = `http://localhost:8003/auth/signup`;

    return async (dispatch, getState) => {
        const result = await fetch(requestURL, {
            method : "POST",
            headers : {
                "Content-Type": "application/json",
                "Accept":"*/*"
                // ,
                // "Access-Controll-Arrow-Origin":"*"
            },
            body: JSON.stringify({
                memberId: form.memberId,
                memberPassword: form.memberPassword,
                memberName : form.memberName,
                memberEmail : form.memberEmail

            })
        }).then(response => response.json());

        console.log('callRegister API result : ', result, ' ....');
        // console.log('callLogin API result : '+result);
        if(result.status === 201){
            dispatch({type: POST_REGISTER, payload : result});
        }
        

    };
}