import{GET_MODERN, GET_CONTEMPORARY, GET_ART, POST_ART, DELETE_ART, PUT_ART} from '../modules/ArtModule.js';

export const callModernListAPI = ({currentPage}) => {
    let requestURL;

    if(currentPage !== undefined || currentPage !== null){
        requestURL = `http://localhost:8003/api/v1/arts/modern?offset=${currentPage}`;
    }else {
        requestURL = `http://localhost:8003/api/v1/arts/modern`;
    }
    
    console.log('[ArtAPICalls] requestURL : ', requestURL);

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"
            }
        })
        .then(response => response.json());
        if(result.status === 200){
            console.log('[ArtAPICalls] callArtListAPI RESULT : ', result);
            dispatch({ type: GET_MODERN,  payload: result.data });
        }
        
    };

}
export const callContemporaryListAPI = ({currentPage}) => {
    let requestURL;

    if(currentPage !== undefined || currentPage !== null){
        requestURL = `http://localhost:8003/api/v1/arts/contemporary?offset=${currentPage}`;
    }else {
        requestURL = `http://localhost:8003/api/v1/arts/contemporary`;
    }
    
    console.log('[ArtAPICalls] requestURL : ', requestURL);

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*",
                "Authorization": "Bearer " + window.localStorage.getItem("accessToken")

            }
        })
        .then(response => response.json());
        if(result.status === 200){
            console.log('[ArtAPICalls] callArtListAPI RESULT : ', result);
            dispatch({ type: GET_CONTEMPORARY,  payload: result.data });
        }
        
    };

}
export const callArtDetailAPI = ({artNo}) => {
    const requestURL = `http://localhost:8003/api/v1/art/${artNo}`;

    return async (dispatch, getState) => {


        const result = await fetch(requestURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "Accept": "*/*"
            }
        })
        .then(response => response.json());

        console.log('[ArtAPICalls] callArtListAPI RESULT : ', result);
        if(result.status === 200){
            console.log('[ArtAPICalls] callArtListAPI SUCCESS');
            dispatch({ type: GET_ART,  payload: result.data });
        }
        
        
    };
}

export const callArtRegistAPI = ({form}) => {
    console.log('[ArtAPICalls] callArtRegistAPI Call');

    const requestURL = `http://localhost:8003/api/v1/arts-management`;

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "POST",
            headers: {
                "Accept": "*/*",
                "Authorization": "Bearer " + window.localStorage.getItem("accessToken")
            },
            body: form
        })
        .then(response => response.json());

        console.log('[ArtAPICalls] callArtRegistAPI RESULT : ', result);

        dispatch({ type: POST_ART,  payload: result });
        
    };    
}

export function callDeleteArtAPI(artNo) {
    
    console.log('deleteArt api calls...');

    const requestURL = `http://localhost:8003/api/v1/arts-management/${artNo}`;
    return async (dispatch, getState) => {

            const result = await fetch(requestURL, {
                method: "DELETE",
                headers: {
                    "Accept": "*/*",
                    "Authorization": "Bearer " + window.localStorage.getItem("accessToken")
                }
            })
            .then(response => response.json());
            console.log('[ArtAPICalls] callArtDeleteAPI RESULT : ', result);

            dispatch({ type: DELETE_ART,  payload: result });
    }
}
export const callArtModifyAPI = ({form, artNo}) => {
    console.log('[ArtAPICalls] callArtModifyAPI Call');

    const requestURL = `http://localhost:8003/api/v1/arts-management/${artNo}`;

    return async (dispatch, getState) => {

        const result = await fetch(requestURL, {
            method: "PUT",
            headers: {
                "Accept": "*/*",
                "Authorization": "Bearer " + window.localStorage.getItem("accessToken")
            },
            body: form
        })
        .then(response => response.json());

        console.log('[ArtAPICalls] callArtModifyAPI RESULT : ', result);

        dispatch({ type: PUT_ART,  payload: result });
        
    };    
}