import MainCSS from './Main.module.css';
import exhibit from './egypt.jpg';
import exhibit2 from './abstract.png';
import exhibit3 from './atlantic.png';
import exhibit4 from './andre.jpg';
import ReactPlayer from 'react-player/lazy';



function Main() {
   
    return (
        <>
            <h3 className={MainCSS.galleryDesc}>온라인 미술관에 오신 것을 환영합니다.
                <br></br>
                1관은 자유롭게 입장하실 수 있으며, 2관은 로그인 하신 회원들께만 개방되어 있습니다</h3>
            <br></br>
            <div style={{justifyItems:"center", justifyContent:"center", textAlign:"center", marginLeft: "auto", marginRight: "auto"}}>
                <ReactPlayer
                    className='react-player'
                    url={"https://youtu.be/MGN9GDFy45c"}
                    width='500px'
                    height={"500px"}
                    playing={true}
                    controls={false}
                    light={true}
                    muted={false}
                    style={{ marginLeft: "auto", marginRight: "auto"}}
                    />
            </div>
            <h3 className={MainCSS.galleryOff}>▽오프라인 전시 일정 확인하기</h3>
            <table className={MainCSS.galleryTable}>
                <tbody>
                    <tr>
                        
                        <td><a href="https://www.sac.or.kr/site/main/show/show_view?SN=46441"><img className={MainCSS.img} src={exhibit} alt="전시1"></img></a>
                        <h5 className={MainCSS.mainh5}>이집트,미라展</h5></td>
                        <td><a href="https://www.lacma.org/art/exhibition/new-abstracts-recent-acquisitions"><img className={MainCSS.img} src={exhibit2} alt="전시2"></img></a>
                        <h5 className={MainCSS.mainh5}>New Abstracts: </h5></td>
                        <td><a href="https://www.lacma.org/art/exhibition/afro-atlantic-histories"><img className={MainCSS.img} src={exhibit3} alt="전시3"></img></a>
                        <h5 className={MainCSS.mainh5}>Afro-Atlantic Histories</h5></td>
                        <td><a href="https://www.sac.or.kr/site/main/show/show_view?SN=46450"><img className={MainCSS.img} src={exhibit4} alt="전시4"></img></a>
                        <h5 className={MainCSS.mainh5}>앙드레 브라질리에 특별전</h5></td>
                    </tr>
                </tbody>
            </table>
        </>
    );
}

export default Main;