import { Navigate, useNavigate} from 'react-router-dom';
import { useEffect, useState } from 'react';
import{useSelector, useDispatch} from 'react-redux';

import{ callRegisterAPI } from '../../apis/MemberAPICalls';
import LoginCSS from './Login.module.css';
function Register(){
    const navigate = useNavigate();

    const dispatch = useDispatch();
    const member = useSelector(state => state.memberReducer);

    const [form, setForm] = useState({
        memberId: '',
        memberPassword: '',
        memberName:'',
        memberEmail:''
    });

    useEffect(()=>{
        if(member.status === 201){
            console.log("Register SUCCESS {}", member);
            navigate("/", { replace: true });
        }
    },[member]);


    const onChangeHandler =(e)=>{
        setForm({
            ...form,
            [e.target.name]: e.target.value
        }  
        );
        // spread 함수를 쓰려면 {}에 써야함
    }
    const registerHandler=()=>{
        dispatch(callRegisterAPI({
            form:form
        }))
    }



    return(
        <div className={LoginCSS.entireLogin}>
            <h1 className={LoginCSS.loginh1}>회원가입</h1>
            <input  className={LoginCSS.loginInfo}
                type="text"
                name="memberId"
                placeholder='아이디 입력'
                onChange={onChangeHandler}
            />
                        <br></br>

            <input className={LoginCSS.loginInfo}
                type="password"
                name="memberPassword"
                placeholder='비밀번호 입력'
                onChange={onChangeHandler}
            />
            <br></br>
            <input className={LoginCSS.loginInfo}
                type="text"
                name="memberName"
                placeholder='이름 입력'
                onChange={onChangeHandler}
            />
                        <br></br>

            <input className={LoginCSS.loginInfo}
                type="text"
                name="memberEmail"
                placeholder='이메일 입력'
                onChange={onChangeHandler}
            />
                        <br></br>

            <button onClick={registerHandler}
            className={LoginCSS.btn}>
                회원가입
            </button>

        </div>
    )
}
export default Register;