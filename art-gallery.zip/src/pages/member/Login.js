import { Navigate, useNavigate} from 'react-router-dom';
import { useEffect, useState } from 'react';
import{useSelector, useDispatch} from 'react-redux';

import{ callLoginAPI } from '../../apis/MemberAPICalls';
import LoginCSS from './Login.module.css';

function Login(){
    const navigate = useNavigate();

    const dispatch = useDispatch();
    const loginMember = useSelector(state => state.memberReducer);

    const [form, setForm] = useState({
        memberId: '',
        memberPassword: ''
    });

    useEffect(()=>{
        if(loginMember.status === 200){
            console.log("[Login] Login SUCCESS {}", loginMember);
            navigate("/", { replace: true });
        }
    },[loginMember]);

    if(loginMember.length>0){
        console.log("Login is already authenticated by server");
        return <Navigate to="/"/>
    }

    const onChangeHandler =(e)=>{
        setForm({
            ...form,
            [e.target.name]: e.target.value
        }  
        );
        // spread 함수를 쓰려면 {}에 써야함
    }
    const onClickHandler=()=>{
        dispatch(callLoginAPI({
            form:form
        }))
    }
    const registerHandler = () =>{
        navigate("/auth/register", {replace:true})
    }
    const returnHandler = () =>{
        navigate("/", {replace:true})
    }

    return(
        <div className={LoginCSS.entireLogin}>
            <h1 className={LoginCSS.loginh1}>로그인</h1>
            
            <input className={LoginCSS.loginInfo}
                type="text"
                name="memberId"
                placeholder='아이디 입력'
                onChange={onChangeHandler}
            />
            <br></br>
            <input className={LoginCSS.loginInfo}
                type="password"
                name="memberPassword"
                placeholder='비밀번호 입력'
                onChange={onChangeHandler}
            />
            <br></br>
            <button onClick={onClickHandler}
            className={LoginCSS.btn}>
                로그인
            </button>
            <button onClick={registerHandler}
             className={LoginCSS.btn}>
                회원가입
            </button>
            <button onClick={returnHandler}
             className={LoginCSS.btn}>
                돌아가기
            </button>

        </div>
    )
}
export default Login;