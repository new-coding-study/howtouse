
import ArtList from "../../components/ArtList";
import {useEffect, useState} from 'react';
import {useSelector, useDispatch} from 'react-redux';
import {useParams } from 'react-router-dom';

import {callModernListAPI} from '../../apis/ArtAPICalls'
import {callContemporaryListAPI} from '../../apis/ArtAPICalls'

import ArtsCSS from './Arts.module.css';

function Arts(){

    const dispatch = useDispatch();
    const arts = useSelector(state=>state.artReducer);

    const artList = arts.data;
    const params = useParams();
    // const artAge = useSelector(state=>state.artReducer.artAge);
    // console.log(artAge);
    console.log(params);
    console.log(params.artAge);
    console.log(params.artAge === 'modern');
    const pageInfo = arts.pageInfo;

    const [currentPage, setCurrentPage] = useState(1);

    const pageNumber = [];
    if(pageInfo){
        for(let i =1 ; i <= pageInfo.endPage; i++){
            pageNumber.push(i);
        }
    }

    useEffect(
        ()=>{
            if(params.artAge === 'modern'){
                dispatch(callModernListAPI({
                    currentPage: currentPage
                }));
            }else{
                dispatch(callContemporaryListAPI({
                    currentPage: currentPage
                }));
            }
            
        }
        ,[currentPage, params.artAge]
    );
    return(

        <div>
               
            <div className={ArtsCSS.container}>
            {
                Array.isArray(artList) && artList.map((art)=>(<ArtList key={art.artNo} art={art}/>))
            }
            </div>
            <div className={ArtsCSS.btnPosition}>
              <div style={{ listStyleType: "none", display: "flex" }}>
                { Array.isArray(artList) &&
                <button
                    className={ArtsCSS.btn}
                    onClick={() => setCurrentPage(currentPage - 1)} 
                    disabled={currentPage === 1}
                    
                >
                    &lt;
                </button>
                }
                {pageNumber.map((num) => (
                <li key={num} onClick={() => setCurrentPage(num)}>
                    <button className={ArtsCSS.btn}
                        style={ currentPage === num ? {backgroundColor : 'orange' } : null}
                        
                    >
                        {num}
                    </button>
                </li>
                ))}
                { Array.isArray(artList) &&
                <button 
                    className={ArtsCSS.btn}
                    onClick={() => setCurrentPage(currentPage + 1)} 
                    disabled={currentPage === pageInfo.endPage  || pageInfo.total === 0}
                >
                    &gt;
                </button>
                }
            </div>
            </div>
        </div>
    );

}

export default Arts;