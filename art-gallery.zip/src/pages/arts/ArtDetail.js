import { useNavigate, useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { useEffect, useState } from 'react';
import { decodeJwt } from '../../utils/tokenUtils';
import {callDeleteArtAPI, callArtDetailAPI} from '../../apis/ArtAPICalls';
import ArtDetailCSS from './ArtDetail.module.css';

function ArtDetail(){
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const params = useParams();
    const art  = useSelector(state => state.artReducer);  
    const isLogin = window.localStorage.getItem('accessToken');    // Local Storage 에 token 정보 확인
    let decoded = null;

    if(isLogin !== undefined && isLogin !== null) {
        const temp = decodeJwt(window.localStorage.getItem("accessToken"));
        decoded = temp.auth[0];
    }
    console.log('decoded ', decoded);
    
    
    console.log(art.artAge);
    
    useEffect(
        () => {
            dispatch(callArtDetailAPI({	// 상품 상세 정보 조회
                artNo: params.artNo
            }));            
        } // eslint-disable-next-line
        ,[]
    );

  

 
    const updateHandler = () => navigate(`/api/v1/arts-management/${params.artNo}`);

    // 메뉴 삭제 버튼을 누르면 API로 id를 보냄 2-4-2
    const deleteHandler = () => {
        dispatch(callDeleteArtAPI(params.artNo));
        alert('작품 삭제');
                navigate(`/api/v1/arts/${art.artAge}`);
    }

 

    return (
        <div className={ArtDetailCSS.entireDetail}>
          

            <div >
                <div >
                    <img className={ArtDetailCSS.img} src={ art.artImageUrl } alt="이미지확인!" />
                    
                </div>
                <div >
                    <table className={ArtDetailCSS.detailTable}>
                        <tbody>
                            <tr>
                                <th>작품명</th>    
                                <td>{ art.artName }</td>
                            </tr>
                            <tr>
                                <th>작가</th>    
                                <td>{ art.authorName }</td>
                            </tr>
                            <tr>
                                <th>위치</th>    
                                <td>{ art.artPlace }</td>
                            </tr>    
                            <tr>
                                <th>제작시기</th>    
                                <td>{ art.artYear }</td>
                            </tr>    
                            <tr>
                                <th>작품 설명</th>    
                                <td>{ art.artDescription }</td>
                            </tr>    
                            <tr>
                                <th>학파</th>    
                                <td>{ art.artMovement }</td>
                            </tr>       
                        </tbody>                    
                    </table>
                    <div>
                    { decoded ==="ROLE_ADMIN" && 
                                    <div className={ArtDetailCSS.btnDiv}>
                                        <button className ={ArtDetailCSS.button} onClick={ updateHandler }>작품 정보 수정</button>
                                        <button className ={ArtDetailCSS.button} onClick={ deleteHandler }>작품 삭제</button>
                                    </div>}
                    </div>
                </div>
            </div>
        </div>
    );
}
export default ArtDetail;