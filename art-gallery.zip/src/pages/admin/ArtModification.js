import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import ArtRegistCSS from './ArtRegistration.module.css';

import{callArtDetailAPI, callArtModifyAPI} from '../../apis/ArtAPICalls'

function ArtModification(){
    const dispatch = useDispatch();
    const params = useParams();
    const artDetail = useSelector(state=>state.artReducer);

    console.log(artDetail);

    const [image, setImage] = useState(null);
    const [imageUrl, setImageUrl] = useState(null);
    const [modifyMode, setModifyMode] = useState(false);
    const imageInput = useRef();
    const navigate = useNavigate();

    const [form, setForm] = useState({});

    useEffect(        
        () => {
            console.log('[ArtModify] art num : ', params.artNo);

            dispatch(callArtDetailAPI({	
                artNo: params.artNo
            }));                     
        } // eslint-disable-next-line
    ,[]);

    useEffect(() => {
        
        // 이미지 업로드시 미리보기 세팅
        if(image){
            const fileReader = new FileReader();
            fileReader.onload = (e) => {
                const { result } = e.target;
                if( result ){
                    setImageUrl(result);
                    console.log("setImageUrl" + result);

                }
            }
            fileReader.readAsDataURL(image);
        }
    },
    [image]);


    const onChangeImageUpload = (e) => {
        console.log(e.target.files[0]);
        const image = e.target.files[0];

        setImage(image);
    };

    const onClickImageUpload = () => {
        if(modifyMode){
            imageInput.current.click();
        }
    }

    const onClickModifyModeHandler = () => {    // 수정모드
        setModifyMode(true);
        setForm({
            artNo: artDetail.artNo,
            artName: artDetail.artName,
            authorName: artDetail.authorName,
            artDescription: artDetail.artDescription,
            artPlace: artDetail.artPlace,
            artAge: artDetail.artAge,
            artImage: artDetail.artImage,
 	        artMovement: artDetail.artMovement,
            artYear: artDetail.artYear
        });
    }

    // form 데이터 세팅    
    const onChangeHandler = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };

    const onClickModifyHandler = () => {

        console.log('[Modification] onClickModifyHandler');

        const formData = new FormData();

        formData.append("artName", form.artName);
        formData.append("authorName", form.authorName);
        formData.append("artDescription", form.artDescription);
        formData.append("artPlace", form.artPlace);
        formData.append("artAge", form.artAge);
        formData.append("artMovement", form.artMovement);
        formData.append("artYear", form.artYear);

        if(image){
            formData.append("artImage", image);
        }

        dispatch(callArtModifyAPI({	// 상품 정보 업데이트
            form: formData, artNo: form.artNo
        }));         
        console.log('저여기 있어요 ',form.artNo)
        navigate(`/api/v1/art/${params.artNo}`, { replace: true});
        window.location.reload();
        // navigate(`/`);
    }
   
    return (
        <div className={ArtRegistCSS.entire}>
            <div >
                <button     className={ArtRegistCSS.btn}   
                    onClick={ () => navigate(-1) }            
                >
                    돌아가기
                </button>
                {!modifyMode &&
                    <button       className={ArtRegistCSS.btn}
                        onClick={ onClickModifyModeHandler }             
                    >
                        수정모드
                    </button>
                }
                {modifyMode &&
                    <button       className={ArtRegistCSS.btn}
                        onClick={ onClickModifyHandler }             
                    >
                        저장하기
                    </button>
                }
            </div>        
            <div >
                <div >
                    <div >
                        { artDetail && <img 
                            style={{height:'300px'}}
                            src={ (imageUrl === null) ? artDetail.artImageUrl : imageUrl } 
                            alt="preview"
                        />}
                        <input                
                            style={ { display: 'none' }}
                            type="file"
                            name='artImage' 
                            accept='image/jpg,image/png,image/jpeg,image/gif'
                            onChange={ onChangeImageUpload }
                            ref={ imageInput }
                        />
                        <br></br>
                        <button 
                            className={ArtRegistCSS.btn}
                            onClick={ onClickImageUpload } 
                        >
                            이미지 업로드
                            </button>
                    </div>
                </div>
                <div >
                    <table className={ArtRegistCSS.table}>
                        <tbody>
                            <tr>
                                <td><label>작품이름</label></td>
                                <td>
                                    <input 
                                        name='artName'
                                        placeholder='작품 이름'
                                        value={ (!modifyMode ? artDetail.artName : form.artName) || ''}
                                        readOnly={ modifyMode ? false : true }
                                        style={ !modifyMode ? { backgroundColor: 'gray'} : null}
                                        className={ ArtRegistCSS.artInfo }
                                        onChange={ onChangeHandler }
                                    />
                                </td>
                            </tr>    
                            <tr>
                                <td><label>작가명</label></td>
                                <td>
                                    <input 
                                        name='authorName'
                                        placeholder='작가명'
                                        value={ (!modifyMode ? artDetail.authorName : form.authorName) || ''}
                                        readOnly={ modifyMode ? false : true }
                                        style={ !modifyMode ? { backgroundColor: 'gray'} : null}
                                        className={ ArtRegistCSS.artInfo }
                                        onChange={ onChangeHandler }
                                    />
                                </td>
                            </tr>    
                            <tr>
                                <td><label>작품 연대</label></td>
                                <td>
                                    <label>
                                        <input type="radio" name="artAge"  
                                        onChange={ onChangeHandler } value="modern"
                                        readOnly={ modifyMode ? false : true } 
                                        checked={ (!modifyMode ? artDetail.artAge : form.artAge) === 'modern' ? true : false }/> 
                                            근대미술</label> &nbsp;
                                    <label>
                                        <input type="radio" name="artAge"  
                                        onChange={ onChangeHandler } value="contemporary"
                                        readOnly={ modifyMode ? false : true } 
                                        checked={ (!modifyMode ? artDetail.artAge : form.artAge) === 'contemporary' ? true : false }
                                        /> 현대미술</label>
                                </td>
                            </tr>    
                            <tr>
                            <td><label>작품 설명</label></td>
                                <td>
                                <textarea 
                                        className={ ArtRegistCSS.artInfo }
                                        name='artDescription'
                                        value={ (!modifyMode ? artDetail.artDescription : form.artDescription) || ''}
                                        readOnly={ modifyMode ? false : true }
                                        style={ !modifyMode ? { backgroundColor: 'gray'} : null}
                                        onChange={ onChangeHandler }
                                    ></textarea>
                            
                                </td>
                            </tr> 
                            <tr>
                                <td><label>작품 전시 장소</label></td>
                                <td>
                                <input 
                                        placeholder='작품 전시 장소'
                                        className={ ArtRegistCSS.artInfo }
                                        name='artPlace'
                                        onChange={ onChangeHandler }
                                        value={ (!modifyMode ? artDetail.artPlace : form.artPlace) || ''}
                                        readOnly={ modifyMode ? false : true }
                                        style={ !modifyMode ? { backgroundColor: 'gray'} : null}
                                    />
                                </td>
                            </tr> 
                            <tr>
                            <td><label>작품 학파</label></td>
                                <td>
                                <input 
                                        placeholder='작품 학파'
                                        className={ ArtRegistCSS.artInfo }
                                        name='artMovement'
                                        onChange={ onChangeHandler }
                                        value={ (!modifyMode ? artDetail.artMovement : form.artMovement) || ''}
                                        readOnly={ modifyMode ? false : true }
                                        style={ !modifyMode ? { backgroundColor: 'gray'} : null}
                                    />
                                </td>
                            </tr> 
                            <tr>
                            <td><label>작품 생성 년도</label></td>
                                <td>
                                <input 
                                        placeholder='작품 생성 시기'
                                        className={ ArtRegistCSS.artInfo }
                                        name='artYear'
                                        onChange={ onChangeHandler }
                                        value={ (!modifyMode ? artDetail.artYear : form.artYear) || ''}
                                        readOnly={ modifyMode ? false : true }
                                        style={ !modifyMode ? { backgroundColor: 'gray'} : null}
                                    />
                                </td>
                            </tr> 
                          
                        </tbody>                        
                    </table>
                </div>
            </div>
        </div>
    );

};
export default ArtModification;