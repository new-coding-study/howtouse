import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';

import {
    callArtRegistAPI
} from '../../apis/ArtAPICalls';

import ArtRegistCSS from './ArtRegistration.module.css';

function ArtRegistration() {


    const dispatch = useDispatch();

    const [image, setImage] = useState(null);
    const [imageUrl, setImageUrl] = useState();
    const imageInput = useRef();
    const navigate = useNavigate();

    const [form, setForm] = useState({
        artName: '',
        authorName: '',
        artDescription: '',
        artPlace: '',
        artAge: '', 
        artMovement: '',
        artYear: ''

    });

    useEffect(() => {
        // 이미지 업로드시 미리보기 세팅
        if(image){
            const fileReader = new FileReader();
            fileReader.onload = (e) => {
                const { result } = e.target;
                if( result ){
                    setImageUrl(result);
                }
            }
            fileReader.readAsDataURL(image);
        }
    },
    [image]);


    const onChangeImageUpload = (e) => {

        const image = e.target.files[0];

        setImage(image);
    };

    const onClickImageUpload = () => {
        imageInput.current.click();
    }


    // form 데이터 세팅    
    const onChangeHandler = (e) => {
        setForm({
            ...form,
            [e.target.name]: e.target.value
        });
    };


    const onClickRegistHandler = () => {

        console.log('[Registration] onClickRegistHandler');

        const formData = new FormData();

        formData.append("artName", form.artName);
        formData.append("authorName", form.authorName);
        formData.append("artDescription", form.artDescription);
        formData.append("artPlace", form.artPlace);
        formData.append("artAge", form.artAge);
        formData.append("artMovement", form.artMovement);
        formData.append("artYear", form.artYear);

        if(image){
            formData.append("artImage", image);
        }
        console.log('[Registration] formData : ', formData.get("artName"));
        console.log('[Registration] formData : ', formData.get("authorName"));
        console.log('[Registration] formData : ', formData.get("artDescription"));
        console.log('[Registration] formData : ', formData.get("artPlace"));
        console.log('[Registration] formData : ', formData.get("artAge"));
        console.log('[Registration] formData : ', formData.get("artMovement"));
        console.log('[Registration] formData : ', formData.get("artYear"));
        console.log('[Registration] formData : ', formData.get("ArtImageUrl"));

        dispatch(callArtRegistAPI({	
            form: formData
        }));        
        
        
        alert('목록으로 이동합니다.');
        navigate(`/api/v1/arts/${form.artAge}`, { replace: true });
        window.location.reload();
    }
    
    

    return (
        <div className={ArtRegistCSS.entire}>
                  { imageUrl && <img 
                                        style={{height:'300px'}}
                                        src={ imageUrl } 
                                        alt="preview"
                                    />}
                                    <input                
                                        style={ { display: 'none' }}
                                        type="file"
                                        name='artImage' 
                                        accept='image/jpg,image/png,image/jpeg,image/gif'
                                        onChange={ onChangeImageUpload }
                                        ref={ imageInput }
                                    />
                    <table className={ArtRegistCSS.table}>
                        <tbody>
                            <tr>
                                <td><label>작품이름</label></td>
                                <td>
                                    <input 
                                        name='artName'
                                        placeholder='작품 이름'
                                        className={ ArtRegistCSS.artInfo }
                                        onChange={ onChangeHandler }
                                    />
                                </td>
                            </tr>    
                            <tr>
                                <td><label>작가명</label></td>
                                <td>
                                    <input 
                                        name='authorName'
                                        placeholder='작가명'
                                        // type='number'
                                        className={ ArtRegistCSS.artInfo }
                                        onChange={ onChangeHandler }
                                    />
                                </td>
                            </tr>    
                            <tr>
                                <td><label>작품 연대</label></td>
                                <td>
                                    <label><input type="radio" name="artAge"  onChange={ onChangeHandler } value="modern"/> 근대미술</label> &nbsp;
                                    <label><input type="radio" name="artAge"  onChange={ onChangeHandler } value="contemporary"/> 현대미술</label>
                                </td>
                            </tr>    
                            <tr>
                            <td><label>작품 설명</label></td>
                                <td>
                                <textarea 
                                        className={ ArtRegistCSS.artInfo }
                                        name='artDescription'
                                        onChange={ onChangeHandler }
                                    ></textarea>
                            
                                </td>
                            </tr> 
                            <tr>
                                <td><label>작품 전시 장소</label></td>
                                <td>
                                <input 
                                        placeholder='작품 전시 장소'
                                        // type='number'
                                        name='artPlace'
                                        onChange={ onChangeHandler }
                                        className={ ArtRegistCSS.artInfo }
                                    />
                                </td>
                            </tr> 
                            <tr>
                            <td><label>작품 학파</label></td>
                                <td>
                                <input 
                                        placeholder='작품 학파'
                                        // type='number'
                                        name='artMovement'
                                        onChange={ onChangeHandler }
                                        className={ ArtRegistCSS.artInfo }
                                    />
                                </td>
                            </tr> 
                            <tr>
                            <td><label>작품 생성 년도</label></td>
                                <td>
                                <input 
                                        placeholder='작품 생성 시기'
                                        // type='number'
                                        name='artYear'
                                        onChange={ onChangeHandler }
                                        className={ ArtRegistCSS.artInfo }
                                    />
                                </td>
                            </tr> 
                          
                        </tbody>                        
                    </table>
                    <div >
                        <div>
                            <button className={ArtRegistCSS.btn}       
                                onClick={ () => navigate(-1) }   
                                style={{marginRight:"10px"}}         
                            >
                                돌아가기
                            </button>
                            <button       className={ArtRegistCSS.btn}
                                onClick={ onClickRegistHandler }             
                                style={{marginleft:"10px", marginRight: "10px"}}
                            >
                                작품 등록
                            </button>
                          
                            <button className={ArtRegistCSS.btn}
                                    onClick={ onClickImageUpload } 
                            >
                                이미지 업로드
                            </button>
                                  
                        </div>        
                    </div>
        </div>
    );
}

export default ArtRegistration;