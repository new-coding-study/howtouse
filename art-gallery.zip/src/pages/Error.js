import { Link } from  'react-router-dom';

// 2-8. 에러 페이지
function Error() {

    return (
        <>
            <h1>404 Error</h1>
            {
                // 404에러 발생 시 메인 페이지로 돌아갈 수 있는 링크를 만들어놓음
            }
            {/* 2-8-1 메인페이지 */}
            <Link to={ '/' }>
                <span>메인으로</span>
            </Link>
        </>
    );
}

export default Error;