import {createActions, handleActions} from 'redux-actions';

const initialState = [];

export const GET_MODERN = 'art/GET_MODERN';
export const GET_CONTEMPORARY = 'art/GET_CONTEMPORARY';
export const GET_ART = 'art/GET_ART';
export const POST_ART= 'art/POST_ART';
export const DELETE_ART= 'art/DELETE_ART';
export const PUT_ART= 'art/PUT_ART';

const actions = createActions({
    [GET_MODERN]: ()=>{},
    [GET_CONTEMPORARY]: ()=>{},
    [GET_ART]: ()=>{},
    [POST_ART]: ()=>{},
    [DELETE_ART]: ()=>{},
    [PUT_ART]:()=>{}
});

const artReducer = handleActions({
    [GET_MODERN]: (state, {payload})=>{
        return payload;
    },
    [GET_CONTEMPORARY]: (state, {payload})=>{
        return payload;
    },
    [GET_ART]: (state, {payload})=>{
        return payload;
    },
    [POST_ART]: (state, {payload})=>{
        return payload;
    },
    [DELETE_ART]: (state, {payload})=>{
        return payload;
    },
    [PUT_ART]: (state, {payload})=>{
        return payload;
    }
}, initialState);

export default artReducer;