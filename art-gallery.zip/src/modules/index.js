import {combineReducers} from 'redux';
import memberReducer from './MemberModule';
import artReducer from './ArtModule';

const rootReducer = combineReducers({
    memberReducer,
    artReducer
});

export default rootReducer;