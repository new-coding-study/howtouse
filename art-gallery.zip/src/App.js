import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './layouts/Layout';
import Main from './pages/Main';
import Arts from './pages/arts/Arts';
import Login from './pages/member/Login';

import Register from './pages/member/Register';
import ArtDetail from './pages/arts/ArtDetail';

import ArtRegistration from './pages/admin/ArtRegistration';
import ArtModification from './pages/admin/ArtModification';

import './App.css';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={ <Layout/>}>
            <Route index element={ <Main/>}/>
              <Route path="api/v1">
                <Route path="arts/:artAge" element={ <Arts/> } />
                <Route path="art/:artNo" element={ <ArtDetail/> } />
                <Route path="arts-management">
                  <Route index element={ <ArtRegistration/> } />
                  <Route path=":artNo" element={ <ArtModification/> } />
                </Route>
              </Route>
              <Route path="auth">
                <Route path="register" element={ <Register/> } />
                <Route path="login" element={ <Login/> } />
              </Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;